# Architecture Design Plans Website

🏗️ A professional e-commerce website for selling architecture design plans with an admin dashboard for management.

## 🌟 Features

### Main Website (`index.html`)
- 📱 Responsive design for all devices
- 🏠 6 product categories (Townhouse, Villa, Bungalow, Apartment, Interior, Commercial)
- 🛒 Shopping cart interface
- 💰 USD pricing
- ✨ Modern, professional UI/UX
- 📧 Contact information section

### Admin Dashboard (`admin.html`)
- 📊 Dashboard with statistics
- 📦 Product management (Add, Edit, Delete)
- 📁 Category management
- 🛒 Order tracking
- ⚙️ Website settings configuration
- 📈 Sales overview

## 🚀 Live Demo

Visit the live website: [Your GitHub Pages URL]

- **Main Website**: `https://[your-username].github.io/[repository-name]/`
- **Admin Panel**: `https://[your-username].github.io/[repository-name]/admin.html`

## 📁 Project Structure

```
architecture-design-website/
├── index.html          # Main website
├── admin.html          # Admin dashboard
└── README.md          # Documentation
```

## 🛠️ Technologies Used

- HTML5
- CSS3 (with custom styling)
- Vanilla JavaScript
- No external dependencies

## 📦 Installation & Deployment

### Option 1: GitHub Pages (Recommended)

1. **Fork or Clone this repository**
   ```bash
   git clone https://github.com/[your-username]/architecture-design-website.git
   ```

2. **Push to your GitHub repository**
   ```bash
   cd architecture-design-website
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

3. **Enable GitHub Pages**
   - Go to your repository on GitHub
   - Click on **Settings**
   - Scroll down to **Pages** section
   - Under **Source**, select `main` branch
   - Click **Save**
   - Your site will be published at `https://[your-username].github.io/[repository-name]/`

### Option 2: Local Development

1. **Clone the repository**
   ```bash
   git clone https://github.com/[your-username]/architecture-design-website.git
   cd architecture-design-website
   ```

2. **Open in browser**
   - Simply open `index.html` in your web browser
   - For admin panel, open `admin.html`

### Option 3: Using Live Server (VS Code)

1. Install "Live Server" extension in VS Code
2. Right-click on `index.html`
3. Select "Open with Live Server"

## 🎨 Customization

### Changing Products

Edit the product cards in `index.html`:

```html
<div class="product-card">
    <div class="product-image">📐</div>
    <div class="product-info">
        <div class="product-category">YOUR CATEGORY</div>
        <h3 class="product-title">Your Product Name</h3>
        <p class="product-description">Your description</p>
        <div class="product-footer">
            <span class="product-price">$XX</span>
            <a href="#" class="add-to-cart">Buy Now</a>
        </div>
    </div>
</div>
```

### Changing Contact Information

Update the contact details in both `index.html` and `admin.html`:

```html
<span>📞 Hotline: +1 (555) 123-4567</span>
<span>📧 Email: info@archdesignplans.com</span>
```

### Changing Colors

Modify the CSS variables in the `<style>` section:

```css
/* Primary Color */
background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);

/* Accent Color */
background: #f59e0b;
```

## 🔐 Admin Access

The admin dashboard (`admin.html`) is currently a front-end demo. To add authentication:

1. Add a login page
2. Implement backend API
3. Use localStorage or cookies for session management
4. Connect to a database (Firebase, MongoDB, etc.)

## 📝 To-Do / Future Enhancements

- [ ] Add backend API integration
- [ ] Implement payment gateway (Stripe, PayPal)
- [ ] Add user authentication
- [ ] Create database for products and orders
- [ ] Add product image upload functionality
- [ ] Implement search and filter features
- [ ] Add email notifications for orders
- [ ] Create product detail pages
- [ ] Add shopping cart functionality
- [ ] Implement order tracking system

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 👤 Author

**Your Name**
- GitHub: [@yourusername](https://github.com/yourusername)
- Email: your.email@example.com

## 🙏 Acknowledgments

- Design inspiration from modern e-commerce platforms
- Icons and emojis from Unicode standard
- Color schemes from Tailwind CSS

## 📞 Support

For support, email info@archdesignplans.com or create an issue in this repository.

---

⭐ If you found this project helpful, please give it a star!

Made with ❤️ in Vietnam
