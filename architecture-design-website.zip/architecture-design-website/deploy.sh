#!/bin/bash

# Architecture Design Website - Quick Deploy Script
# This script helps you quickly deploy your website to GitHub

echo "🚀 Architecture Design Website - GitHub Deployment Script"
echo "=========================================================="
echo ""

# Check if git is installed
if ! command -v git &> /dev/null
then
    echo "❌ Git is not installed. Please install Git first:"
    echo "   - Windows: https://git-scm.com/download/win"
    echo "   - Mac: brew install git"
    echo "   - Linux: sudo apt-get install git"
    exit 1
fi

echo "✅ Git is installed"
echo ""

# Check if this is already a git repository
if [ -d ".git" ]; then
    echo "📁 Git repository already initialized"
else
    echo "📁 Initializing Git repository..."
    git init
    echo "✅ Git repository initialized"
fi

echo ""

# Ask for GitHub username
read -p "Enter your GitHub username: " github_user

if [ -z "$github_user" ]; then
    echo "❌ GitHub username cannot be empty"
    exit 1
fi

# Ask for repository name
read -p "Enter repository name [architecture-design-website]: " repo_name
repo_name=${repo_name:-architecture-design-website}

echo ""
echo "📝 Configuration:"
echo "   GitHub User: $github_user"
echo "   Repository: $repo_name"
echo ""

# Ask for confirmation
read -p "Is this correct? (y/n): " confirm
if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
    echo "❌ Deployment cancelled"
    exit 1
fi

echo ""
echo "🔄 Preparing files..."

# Add all files
git add .

# Check if there are changes to commit
if git diff-index --quiet HEAD --; then
    echo "ℹ️  No changes to commit"
else
    # Ask for commit message
    read -p "Enter commit message [Initial commit]: " commit_msg
    commit_msg=${commit_msg:-Initial commit}
    
    echo "💾 Committing changes..."
    git commit -m "$commit_msg"
    echo "✅ Changes committed"
fi

echo ""

# Check if remote already exists
if git remote get-url origin &> /dev/null; then
    echo "📡 Remote 'origin' already exists"
    remote_url=$(git remote get-url origin)
    echo "   Current URL: $remote_url"
    read -p "Update remote URL? (y/n): " update_remote
    if [ "$update_remote" = "y" ] || [ "$update_remote" = "Y" ]; then
        git remote remove origin
        git remote add origin "https://github.com/$github_user/$repo_name.git"
        echo "✅ Remote URL updated"
    fi
else
    echo "📡 Adding remote repository..."
    git remote add origin "https://github.com/$github_user/$repo_name.git"
    echo "✅ Remote repository added"
fi

echo ""
echo "🚀 Pushing to GitHub..."

# Push to GitHub
git branch -M main
if git push -u origin main; then
    echo ""
    echo "🎉 =========================================================="
    echo "🎉 SUCCESS! Your website has been deployed to GitHub!"
    echo "🎉 =========================================================="
    echo ""
    echo "📍 Your repository: https://github.com/$github_user/$repo_name"
    echo ""
    echo "📋 Next steps:"
    echo "   1. Go to: https://github.com/$github_user/$repo_name/settings/pages"
    echo "   2. Under 'Source', select 'main' branch"
    echo "   3. Click 'Save'"
    echo "   4. Wait 1-2 minutes for deployment"
    echo ""
    echo "🌐 Your website will be available at:"
    echo "   Main site: https://$github_user.github.io/$repo_name/"
    echo "   Admin panel: https://$github_user.github.io/$repo_name/admin.html"
    echo ""
else
    echo ""
    echo "❌ =========================================================="
    echo "❌ Push failed. Please check the following:"
    echo "❌ =========================================================="
    echo ""
    echo "1. Make sure the repository exists on GitHub:"
    echo "   https://github.com/$github_user/$repo_name"
    echo ""
    echo "2. If the repository doesn't exist, create it first:"
    echo "   https://github.com/new"
    echo ""
    echo "3. Make sure you have access to the repository"
    echo ""
    echo "4. Try running this command manually:"
    echo "   git push -u origin main"
    echo ""
fi
