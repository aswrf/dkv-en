# Hướng Dẫn Deploy Lên GitHub Pages

## Bước 1: Chuẩn Bị

### 1.1. Tạo tài khoản GitHub (nếu chưa có)
- Truy cập: https://github.com
- Click "Sign up"
- Làm theo hướng dẫn để tạo tài khoản

### 1.2. Cài đặt Git (nếu chưa có)
- **Windows**: Tải về từ https://git-scm.com/download/win
- **Mac**: 
  ```bash
  brew install git
  ```
- **Linux**: 
  ```bash
  sudo apt-get install git
  ```

### 1.3. Cấu hình Git (lần đầu tiên)
Mở Terminal/Command Prompt và chạy:
```bash
git config --global user.name "Tên của bạn"
git config --global user.email "email@example.com"
```

## Bước 2: Tạo Repository Trên GitHub

1. Đăng nhập vào GitHub
2. Click nút **"+"** ở góc trên bên phải → chọn **"New repository"**
3. Điền thông tin:
   - **Repository name**: `architecture-design-website` (hoặc tên bạn muốn)
   - **Description**: `Professional architecture design plans e-commerce website`
   - **Public** (chọn Public để dùng GitHub Pages miễn phí)
   - ✅ Tick vào **"Add a README file"** (hoặc không cũng được)
4. Click **"Create repository"**

## Bước 3: Upload Code Lên GitHub

### Phương Án A: Sử dụng Git Command Line (Khuyên dùng)

1. **Mở Terminal/Command Prompt**

2. **Di chuyển đến thư mục chứa code**
   ```bash
   cd đường-dẫn-đến-thư-mục/architecture-design-website
   ```

3. **Khởi tạo Git repository**
   ```bash
   git init
   ```

4. **Thêm tất cả file**
   ```bash
   git add .
   ```

5. **Commit**
   ```bash
   git commit -m "Initial commit - Architecture Design Website"
   ```

6. **Kết nối với GitHub repository**
   ```bash
   git remote add origin https://github.com/TÊN-USER-CỦA-BẠN/architecture-design-website.git
   ```
   
   ⚠️ **Thay thế** `TÊN-USER-CỦA-BẠN` bằng username GitHub của bạn

7. **Push code lên GitHub**
   ```bash
   git branch -M main
   git push -u origin main
   ```

8. **Nhập thông tin đăng nhập GitHub** khi được yêu cầu

### Phương Án B: Sử dụng GitHub Desktop (Dễ hơn)

1. **Tải GitHub Desktop**: https://desktop.github.com/
2. **Cài đặt và đăng nhập**
3. Click **"File"** → **"Add Local Repository"**
4. Chọn thư mục `architecture-design-website`
5. Click **"Publish repository"**
6. Chọn **"Public"** và click **"Publish"**

### Phương Án C: Upload Trực Tiếp Trên Web (Đơn giản nhất)

1. Vào repository vừa tạo trên GitHub
2. Click **"uploading an existing file"**
3. Kéo thả hoặc chọn tất cả file:
   - `index.html`
   - `admin.html`
   - `README.md`
   - `.gitignore`
   - `LICENSE`
4. Thêm commit message: `Initial commit`
5. Click **"Commit changes"**

## Bước 4: Kích Hoạt GitHub Pages

1. **Vào repository trên GitHub**

2. **Click tab "Settings"** (⚙️ Cài đặt)

3. **Tìm phần "Pages"** ở menu bên trái
   - Hoặc truy cập trực tiếp: `https://github.com/TÊN-USER/TÊN-REPO/settings/pages`

4. **Cấu hình GitHub Pages**:
   - **Source**: Chọn `Deploy from a branch`
   - **Branch**: Chọn `main` (hoặc `master`)
   - **Folder**: Chọn `/ (root)`
   - Click **"Save"**

5. **Đợi 1-2 phút** để GitHub build và deploy

6. **Kiểm tra**:
   - Refresh lại trang
   - Bạn sẽ thấy thông báo: "Your site is live at https://TÊN-USER.github.io/architecture-design-website/"

## Bước 5: Truy Cập Website

### URL của bạn sẽ là:
- **Trang chủ**: `https://TÊN-USER.github.io/TÊN-REPO/`
- **Admin panel**: `https://TÊN-USER.github.io/TÊN-REPO/admin.html`

Ví dụ:
- `https://duongdang.github.io/architecture-design-website/`
- `https://duongdang.github.io/architecture-design-website/admin.html`

## Bước 6: Cập Nhật Website (Sau Này)

Khi bạn muốn thay đổi nội dung:

### Sử dụng Git:
```bash
# 1. Sửa file (index.html, admin.html, etc.)

# 2. Thêm thay đổi
git add .

# 3. Commit
git commit -m "Update products and prices"

# 4. Push lên GitHub
git push origin main
```

### Sử dụng GitHub Web:
1. Vào repository
2. Click vào file cần sửa
3. Click icon ✏️ (Edit)
4. Sửa nội dung
5. Scroll xuống dưới
6. Thêm commit message
7. Click **"Commit changes"**

⏱️ **Đợi 1-2 phút** để thay đổi có hiệu lực

## 🎯 Mẹo & Lưu Ý

### ✅ Custom Domain (Tùy chọn)
Nếu bạn có tên miền riêng:
1. Vào Settings → Pages
2. Phần **"Custom domain"**
3. Nhập tên miền: `www.yoursite.com`
4. Cấu hình DNS theo hướng dẫn của GitHub

### ✅ HTTPS
- GitHub Pages tự động cung cấp HTTPS miễn phí
- Tick vào **"Enforce HTTPS"** trong Settings → Pages

### ✅ SEO
- Thêm file `robots.txt`
- Thêm file `sitemap.xml`
- Thêm Google Analytics

### ⚠️ Lưu Ý
- GitHub Pages miễn phí có giới hạn: 100GB bandwidth/tháng
- Repository phải là **Public** để dùng GitHub Pages miễn phí
- Nếu muốn Private repo + GitHub Pages → cần GitHub Pro ($4/tháng)

## 🐛 Xử Lý Lỗi

### Lỗi 404 - Not Found
- Kiểm tra tên file phải là `index.html` (chữ thường)
- Đợi 5-10 phút sau khi deploy
- Xóa cache trình duyệt (Ctrl + Shift + Del)

### Thay đổi không hiển thị
- Xóa cache trình duyệt
- Thử trình duyệt ẩn danh
- Đợi thêm vài phút

### Lỗi Git Push
- Kiểm tra đã đăng nhập đúng tài khoản
- Thử xóa và add lại remote:
  ```bash
  git remote remove origin
  git remote add origin URL-CỦA-BẠN
  git push -u origin main
  ```

## 📚 Tài Liệu Tham Khảo

- GitHub Pages: https://pages.github.com/
- Git Documentation: https://git-scm.com/doc
- GitHub Docs: https://docs.github.com/

## 💬 Hỗ Trợ

Nếu gặp vấn đề, bạn có thể:
1. Tạo Issue trên GitHub repository
2. Tham khảo GitHub Community
3. Liên hệ qua email

---

🎉 **Chúc mừng! Website của bạn đã online!** 🎉
