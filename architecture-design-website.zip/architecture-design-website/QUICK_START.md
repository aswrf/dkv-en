# ⚡ Quick Start - Deploy in 5 Minutes

## 🎯 Fastest Way to Deploy

### Option 1: Using Deploy Script (Recommended)

1. **Open Terminal/Command Prompt in project folder**

2. **Run the deploy script:**
   ```bash
   ./deploy.sh
   ```

3. **Follow the prompts:**
   - Enter your GitHub username
   - Enter repository name (or press Enter for default)
   - Confirm

4. **The script will automatically:**
   - Initialize Git
   - Add all files
   - Commit changes
   - Push to GitHub

5. **Enable GitHub Pages:**
   - Go to: `https://github.com/YOUR-USERNAME/REPO-NAME/settings/pages`
   - Select `main` branch
   - Click Save
   - Wait 2 minutes

6. **Visit your site:**
   - `https://YOUR-USERNAME.github.io/REPO-NAME/`

---

### Option 2: Manual Deploy (3 Commands)

```bash
# 1. Initialize and commit
git init
git add .
git commit -m "Initial commit"

# 2. Connect to GitHub (replace with your info)
git remote add origin https://github.com/YOUR-USERNAME/REPO-NAME.git

# 3. Push
git branch -M main
git push -u origin main
```

Then enable GitHub Pages in repository settings.

---

### Option 3: Upload via GitHub Web

1. Create new repository on GitHub
2. Click "uploading an existing file"
3. Drag and drop all files
4. Commit
5. Enable GitHub Pages in Settings

---

## 📝 Prerequisites

Before deploying, make sure you have:

- ✅ GitHub account
- ✅ Git installed (check with `git --version`)
- ✅ All project files in one folder

## 🔧 First Time Git Setup

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

## 🎨 After Deployment

### Update Website Content:

```bash
# 1. Edit files (index.html, admin.html)
# 2. Commit and push
git add .
git commit -m "Update content"
git push origin main
```

Changes will appear in 1-2 minutes.

### Access Your Website:

- **Main Site**: `https://USERNAME.github.io/REPO-NAME/`
- **Admin Panel**: `https://USERNAME.github.io/REPO-NAME/admin.html`

---

## 🆘 Troubleshooting

### "git: command not found"
Install Git: https://git-scm.com/downloads

### "Permission denied"
Run: `chmod +x deploy.sh`

### "Repository not found"
Create repository first: https://github.com/new

### Changes not showing
- Clear browser cache (Ctrl + Shift + Del)
- Wait 5 minutes
- Try incognito mode

---

## 📚 Full Documentation

For detailed instructions, see:
- [DEPLOYMENT_GUIDE_VI.md](DEPLOYMENT_GUIDE_VI.md) (Vietnamese)
- [README.md](README.md) (English)

---

## 💡 Tips

- Use **Public** repository for free GitHub Pages
- Repository name becomes part of URL
- Choose a short, memorable name
- Use hyphens instead of spaces

---

**Need help?** Create an issue on GitHub or check the full deployment guide.

🚀 **Happy Deploying!**
